package animation.xyz.animation

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button

class MainActivity : AppCompatActivity() {
    var b: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        b = findViewById<View>(R.id.android1) as Button
        b!!.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this@MainActivity, R.anim.mixed_anim)
            b!!.startAnimation(animation)
        }
    }
}