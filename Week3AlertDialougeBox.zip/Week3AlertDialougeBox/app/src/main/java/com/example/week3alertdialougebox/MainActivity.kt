package com.example.week3alertdialougebox

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.week3alertdialougebox.ExampleDialog.ExampleDialogListener

class MainActivity : AppCompatActivity(), ExampleDialogListener {
    private var textViewUsername: TextView? = null
    private var textViewPassword: TextView? = null
    private var button: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textViewUsername = findViewById<View>(R.id.textview_username) as TextView
        textViewPassword = findViewById<View>(R.id.textview_password) as TextView
        button = findViewById<View>(R.id.button) as Button
        button!!.setOnClickListener { openDialog() }
    }

    fun openDialog() {
        val exampleDialog = ExampleDialog()
        exampleDialog.show(supportFragmentManager, "example dialog")
    }

    override fun applyTexts(username: String?, password: String?) {
        textViewUsername!!.text = username
        textViewPassword!!.text = password
    }
}