package com.imake.wifimanagerwrapper.util.wifiwrapper

interface WifiConnectivityCallbackResult {
    fun wifiConnectionStatusChangedResult()
}