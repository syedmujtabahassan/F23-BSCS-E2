package com.wifimanagerwrapper

interface WifiConnectivityCallbackResult {
    fun wifiConnectionStatusChangedResult()
}