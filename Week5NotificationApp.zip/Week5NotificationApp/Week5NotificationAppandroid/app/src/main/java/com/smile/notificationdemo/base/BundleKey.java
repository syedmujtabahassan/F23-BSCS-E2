package com.smile.notificationdemo.base;

/**
 * @author Smile Wei
 * @since 2017/8/4.
 */

public class BundleKey {

    public final static String TEXT = "text";
}
